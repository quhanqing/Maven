import java.util.Scanner;

public class Test4 {
    public static void main(String[] args){
        int i=1;
        int num=(int)(Math.random()*1000);
        System.out.println(num);
        System.out.println("请输入0-1000的数字，退出请按0：");
        Scanner scanner=new Scanner(System.in);
        int guest=scanner.nextInt();


    while(guest!=num){
        if(guest==0){
            System.out.println("game over!");
            break;
        }
        else if(guest>num){
            System.out.println("太大了，请重新输入");
        }
        else {
            System.out.println("太小啦，请重新输入");
        }
        System.out.println("请重新输入：");
        guest=scanner.nextInt();

    }

        if(guest==num) {
            System.out.println("猜对啦");}


      }
    }



