public class Test2 {
    public static void main(String[] args){
        int sum=0;
        double chengji=1;
        for(int i=1;i<=100;i++) {

            sum=sum+i;
            if(sum>4000){
                break;
            }
        }
        System.out.println("总数为"+sum);

        for(int b=1;b<=5;b++){
            chengji=chengji*b;
        }
        System.out.println("乘积为"+chengji);

        /*do{
            System.out.println("未成年");
            age++;
        }
        while (age <3);
*/



        /*while(age<=16){我
            if (age==5){
                break;
            }
            System.out.println("未成年");
            age++;
        }
        System.out.println("成年啦");
*/


    }
}
