
public class TestOne {
    public static void main(String[] args){
        String name="Tracy";
        int a=5;
        String msg="a="+a;
        int b=6;
        int c=b%a;
        int age=18;
        String MobilePhone="15101543275";
        long money=999999;
        char sex='女';
        char single='是';
        float height=174.8f;
        double weight=59.89;
        System.out.println("我的名字是"+name+"，我的年龄是"+age+"，我的手机号是"+MobilePhone+",我"+single+"单身"+
                "，我的存款是"+money+"，我的性别是"+sex+"，我的身高是"+height+"，我的体重是"+weight+"。");

        System.out.println(Long.SIZE);
        System.out.println(Long.MAX_VALUE);


        System.out.println(a+""+b);
        System.out.println("c="+c);
        System.out.println(msg);

        final  double yuan_zhou_lv=3.1415;

        int num=49;
        int numq=num++;
        System.out.println(num);
        System.out.println(numq);


    }
}
