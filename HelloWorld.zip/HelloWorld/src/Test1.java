import java.util.Scanner;

public class Test1 {

    public static void main(String[] args){
        Scanner scanner=new Scanner(System.in);
        System.out.println("请输入年份：");
        int year=scanner.nextInt();
        scanner.close();

        int a=year%4;
        int b=year%100;
        int c=year%400;
        boolean isRunYear=((a==0 && b!=0)||(c==0));
        String msg=isRunYear?year+"是闰年":year+"非闰年";
        System.out.println(msg);

       /* if((a==0 && b!=0)||(c==0)){
            System.out.println("闰年");
        }

        else{
            System.out.println("非闰年");
        }
        */
    }

}
