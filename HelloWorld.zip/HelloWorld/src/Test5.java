import java.util.Scanner;

public class Test5 {
    public static void main(String[] args) {
        System.out.println("输入1开始，输入除1外任何字符退出");
        Scanner scanner=new Scanner(System.in);
        int type=scanner.nextInt();
        int sum=0;
        if(type==1) {
            System.out.println("需做完10道题，可查看得分");


            for (int i = 1; i <= 10; i++) {
                int a = (int) (Math.random() * 100);
                int b = (int) (Math.random() * 100);
                int c = a + b;
                System.out.println("请输入答案" + a + "+" + b + "=");
                int answer = scanner.nextInt();
                if(answer==-1){
                     System.out.println("退出");
                     break;
                 }
                 if(answer==c){
                     System.out.println("回答正确，加10分");
                     sum+=10;
                 }
                 else{
                     System.out.println("回答错误");
                 }
            }
                 System.out.println("总分为："+sum);
        }
        else{
            System.out.println("退出");
        }

    }
}
