

public class Mall {
    public static void main(String[] args) {
        double price = 3.6;
        int count = 200;
        double smallChange;
        double sumprice = price * count;
        double amount = 401;
        int score=60;
        int a=1;


        if(score>=90){
            System.out.println("A级");
        }
        else if(score>=80) {
            System.out.println("B级");
        }
        else if(score>=70) {
            System.out.println("C级");
        }
        else{
            System.out.println("D级");
        }



        if (sumprice >= 500) {
            sumprice = sumprice * 0.8;
        }
        if (amount >= sumprice) {
            smallChange = amount - sumprice;
            System.out.println("应收金额" + sumprice + "，找零" + smallChange);
        }
        else{
            System.out.println("抱歉，您钱不够，再多给点");
        }
    }
}