public class Test6 {
    public static void main(String[] args){

        int[] arr={1,5,7,9,11,13,14,56,23,22,56,78,90};
        for(int i=0;i<arr.length;i++){
            if(arr[i]==90){
                System.out.println("输出："+arr[i]);
                break;
            }
        }


    }
}
