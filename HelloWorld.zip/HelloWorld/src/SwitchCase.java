public class SwitchCase {
    public static void main(String[] agrs){
        int a=3;
        switch (a){
            case 1:
                System.out.println("查询余额");
                break;
            case 2:
                System.out.println("人工服务");
                break;
            case 3:
                System.out.println("其他服务");
                break;

                default:
                System.out.println("退出");


        }





    }

}

